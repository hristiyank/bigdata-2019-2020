var myWallet        = require('./src/wallet');
var myBlockchain    = require('./src/blockchain');
var myUtil          = require('./util/util');

var currencies = {
	'Bitcoin': 1,
	'Litecoin': 157.114780,
	'Zcash': 261.760740
};

var wallet = myWallet.generateWallet();
document.getElementById("wallet-id").innerHTML = wallet.id;
document.getElementById("wallet-amount").innerHTML = wallet.amount;
document.getElementById("wallet-currency").innerHTML = wallet.currency;

var uiWallet = document.getElementById("wallet-tab");
var uiCurrency = document.getElementById("currency-tab");

// get active wallet collection 
var currencyCollection = myBlockchain.syncWalletCollection();
var stringBuilderCurrency   = [];
var templateCurrency = '';
var active = 'active';
var ariaSelected = true;

var stringBuilderWallet = [];
var templateWallet = '';

for(var i = 0; i < currencyCollection.length; i++) {

    var id = currencyCollection[i].id;
    var walletCollection = currencyCollection[i].wallets;
	if (i > 0) {
		active = '';
		ariaSelected = false;
	}
    templateCurrency = '<a class="nav-item nav-link ' + active + '" id="' + id + '" role="tab" href="#" onclick="showTab(this)">' + id + '</a>';
    stringBuilderCurrency.push(templateCurrency);
	
	templateWallet = '<div class="tab-pane fade show ' + active + '" id="nav-' + id + '" role="tabpanel"><p></p><table class="table table-hover"><tbody>';
	stringBuilderWallet.push(templateWallet);
	
	for(var j = 0; j < walletCollection.length; j++) {

		var idWallet = walletCollection[j].id;
		var amount = walletCollection[j].amount;
		templateWallet = '<tr><td>' + idWallet + '</td><td id="wallet-' + i + j + '">' + amount + '</td><td><button type="button" class="btn btn-secondary" onclick="showModal(' + i + ', ' + j + ')" data-params="">Send monney</button></td></tr>';
		stringBuilderWallet.push(templateWallet);
	}
	
	stringBuilderWallet.push('</tbody></table></div>');
}

uiCurrency.innerHTML = stringBuilderCurrency.join('');
uiWallet.innerHTML = stringBuilderWallet.join('');

function showTab(element) {
	var id = "nav-" + element.id;
	var tab = document.getElementById(id);
	var elems = document.querySelectorAll(".active");
	[].forEach.call(elems, function(el) {
		el.classList.remove("active");
	});
	
	element.classList.add("active");
	tab.classList.add("active");
}

function showModal(currencyIndex, walletIndex) {
	document.getElementById('amount-to-send').autofocus
	document.getElementById('sendMoneyModal').classList.add("show");
	var modalCurrency = currencyCollection[currencyIndex];
	var modalWallet = modalCurrency.wallets[walletIndex];
	
	document.getElementById('person-to-send').innerHTML = modalWallet.id;
	document.getElementById('modal-save-btn').setAttribute('data-params-i', currencyIndex);
	document.getElementById('modal-save-btn').setAttribute('data-params-j', walletIndex);
}

function closeModal() {
	document.getElementById('amount-to-send').value = '';
	document.getElementById('modal-error').classList.add('hide');
	document.getElementById('sendMoneyModal').classList.remove("show");
}

function sendMoney(element) {
	var currencyIndex = element.getAttribute('data-params-i');
	var walletIndex = element.getAttribute('data-params-j');
	var modalCurrency = currencyCollection[currencyIndex];
	var modalWallet = modalCurrency.wallets[walletIndex];
	var amountToSend = document.getElementById('amount-to-send').value;
	amountToSend = parseInt(amountToSend);
	var errorEl = document.getElementById('modal-error');
	
	if (amountToSend > wallet.amount) {
		errorEl.innerHTML = "You don't have enough money!";
		errorEl.classList.remove('hide');
		return;
	}
	
	wallet.amount -= amountToSend;
	amountToSend = (modalCurrency.id == wallet.currency) ? amountToSend : amountToSend * currencies[modalCurrency.id];
	
	currencyCollection[currencyIndex].wallets[walletIndex].amount += amountToSend;
	document.getElementById("wallet-amount").innerHTML = wallet.amount;
	document.getElementById("wallet-" + currencyIndex + walletIndex).innerHTML = currencyCollection[currencyIndex].wallets[walletIndex].amount;
	
	document.getElementById('amount-to-send').value = '';
	errorEl.classList.add('hide');
	document.getElementById('sendMoneyModal').classList.remove("show");
}
