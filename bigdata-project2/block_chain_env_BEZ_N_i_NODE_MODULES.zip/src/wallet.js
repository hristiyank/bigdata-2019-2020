var fs = require('fs');

var generateWallet = function() {

    return {
        id      : 'Hristiyan Kirov',
        amount  : 1000,
		currency: 'Bitcoin'
    };
};

var saveWallet = function(walletObject) {

    var walletStringRepresentation = JSON.stringify(walletObject);
    fs.writeFileSync('_meta/_wallet', walletStringRepresentation);
};

module.exports = {
    generateWallet  : generateWallet,
    saveWallet      : saveWallet
}
