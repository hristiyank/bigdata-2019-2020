var fs = require('fs');

var loginUser = function(username) {
	var contents = fs.readFileSync('_meta/_user', 'utf8');
	var users = JSON.parse(contents);
	var user = {};

	for (i = 0; i < users.length; i++) {
		if (users[i].username == username) {
			user = users[i];
		}
	}
	
	return user;
}

module.exports = {
    loginUser : loginUser
}