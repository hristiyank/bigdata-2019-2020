var syncWalletCollection = function() {

    // HTTP request over the network 

    // Get all wollet artefacts

    // return all wallets
    return [
		{
			id: 'Bitcoin',
			wallets: [
				{
					id      : 'Hristo Dimitrov',
					amount  : 700
				},
				{
					id      : 'Hristina Kirova',
					amount  : 100
				},
				{
					id      : 'Ivailo Hristov',
					amount  : 50
				}
			]
		},
		{
			id: 'Litecoin',
			wallets: [
				{
					id      : 'Petya Chalamova',
					amount  : 900
				},
				{
					id      : 'Ivan Petrov',
					amount  : 150
				},
				{
					id      : 'Anna Vracheva',
					amount  : 65
				},
				{
					id      : 'Kalin Stoyanov',
					amount  : 0
				}
			]
		},
		{
			id: 'Zcash',
			wallets: [
				{
					id      : 'Mihail Moravenov',
					amount  : 650
				},
				{
					id      : 'Dimitar Talev',
					amount  : 200
				}
			]
		}
    ];
};

module.exports = {
    syncWalletCollection : syncWalletCollection
}