var fs = require('fs');

var generateWallet = function() {

    return {
        walletId      : 'ecc2397d8daf63e97052a9c0276af236128a6e570946eef71db33bf811ae97ca'
    };
};


var saveWallet = function(walletObject) {

    var walletStringRepresentation = JSON.stringify(walletObject);
    fs.writeFileSync('my-wallet/wallet.json', walletStringRepresentation);
};

module.exports = {
    generateWallet  : generateWallet,
    saveWallet      : saveWallet
}

// # Valid way of writing exports
// module.exports = {
//     generateWallet  : genefunction() {

//         return {
//             id      : 'Mihail Petrov',
//             amount  : 0
//         };
//     }ateWallet,
//     saveWallet      : function(walletObject) {
//         fs.writeFileSync('_meta/_wallet', walletObject);
//     }
// }