
// var generateWallet = function() {
//     return {
//         id      : 'abcd',
//         amount  : 0
//     }
// }

// # Example object
// var SampleWallet = {
//     id     : 'abcd',
//     amount : 0
// };

// var SampleGeneratedWallet = generateWallet();

// console.log(SampleGeneratedWallet);


// # object fuynction call
// var Blockchain = {
//     id : 'abcd',
//     syncBlockchain : function() {
//         console.log('Sync all Blockchain nodes');
//     }
// };

// #proeprty call
// Blockchain.id

// #function call
// Blockchain.syncBlockchain();
// console.log()


// # file systemn module call
// var fs = require('fs');

// # sample file write process
// fs.writeFileSync('sample_fs_file.txt', 'Hellow world');

// * fs
// * http
// * crypto

// напражете си папка sample_fs 
// да се генерират 10 фаила с различно име и 
// сьдьржание в папката

// for(var i = 0; i < 10; i++) {
    
//     var name = 'sample_fs/sample_' + i;
//     var content = 'sample_content' + i;
//     fs.writeFileSync(name, content);
// }

var myWallet        = require('./wallet');
var myBlockchain    = require('./blockchain');

var walletReference = myWallet.generateWallet();
myWallet.saveWallet(walletReference);

// get HTML element by ID identificator
document.getElementById("wallet-id").innerHTML = walletReference.id;

// get amount data
document.getElementById("wallet-amount").innerHTML = walletReference.amount;

var uiWalletTransaction = document.getElementById("wallet-transaction-panel");

// get active wallet collection 
var walletCollection = myBlockchain.syncWalletCollection();

var stringBuilder   = [];
var template        = '';
for(var i = 0; i < walletCollection.length; i++) {

    var id      = walletCollection[i].id;
    var amount  = walletCollection[i].amount;
    template    = '<div>' + id + ' / ' + amount + '</div>';
    stringBuilder.push(template);
}

uiWalletTransaction.innerHTML = stringBuilder.join('');

